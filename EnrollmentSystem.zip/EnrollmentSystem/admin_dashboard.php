<?php
session_start();
include 'connect.php';
require_once 'includes/header.php';

/* =========================
   ADMIN ONLY ACCESS
========================= */
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit();
}

/* =========================
   JOIN QUERY (FIXED)
========================= */
$sql = "
SELECT 
    users.id,
    users.fullname,
    tblstudent.yearlevel,
    tblprogram.program_name
FROM users
INNER JOIN tblstudent
    ON users.id = tblstudent.user_id
LEFT JOIN tblprogram
    ON tblstudent.program_id = tblprogram.program_id
WHERE users.role = 'student'
";

$resultset = $conn->query($sql);

if(!$resultset){
    die("Query Failed: " . $conn->error);
}

/* =========================
   KPI QUERIES (JOIN FIXED)
========================= */
$totalStudents = $conn->query("
SELECT users.id
FROM users
INNER JOIN tblstudent
ON users.id = tblstudent.user_id
WHERE users.role='student'
")->num_rows;

$enrolledStudents = $conn->query("
SELECT users.id
FROM users
INNER JOIN tblstudent
ON users.id = tblstudent.user_id
WHERE users.role='student' AND tblstudent.status='Enrolled'
")->num_rows;

?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>

<style>
body{
    font-family: Arial;
    margin: 0;
    background: linear-gradient(-45deg, #f4f6f9, #e0f2fe, #fefce8, #e2e8f0);
    background-size: 400% 400%;
    animation: bgMove 12s ease infinite;
}

@keyframes bgMove{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
}

.topbar{
    background: linear-gradient(90deg, #ffe600, #ffd000);
    padding: 20px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 3px solid #d6d600;
}

.btn{
    padding: 11px 18px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    text-decoration: none;
    font-size: 14px;
    color: white;
    margin-left: 8px;
}

.btn-add{ background:#007bff; }
.btn-logout{ background:#6c757d; }

.kpi-grid{
    display:grid;
    grid-template-columns: repeat(3,1fr);
    gap:20px;
    padding:25px 50px;
}

.kpi-card{
    background:white;
    padding:20px;
    border-radius:14px;
    box-shadow:0 10px 25px rgba(0,0,0,0.06);
}

.container{ padding:50px; }

.card{
    background:white;
    padding:30px;
    border-radius:14px;
    box-shadow:0 15px 35px rgba(0,0,0,0.08);
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#007bff;
    color:white;
    padding:14px;
    text-align:left;
}

td{
    padding:14px;
    border-bottom:1px solid #eee;
}

.status{
    background:#16a34a;
    color:white;
    padding:5px 10px;
    border-radius:6px;
    font-size:12px;
}
</style>

</head>

<body>

<!-- TOP BAR -->
<div class="topbar">
    <h2>ADMIN DASHBOARD</h2>

    <div>
        <a href="admin_register_user.php" class="btn btn-add">+ Add Student</a>
        <a href="login.php" class="btn btn-logout">Logout</a>
    </div>
</div>

<!-- KPI -->
<div class="kpi-grid">

    <div class="kpi-card">
        <h4>Total Students</h4>
        <h2><?php echo $totalStudents; ?></h2>
    </div>

    <div class="kpi-card">
        <h4>Enrolled Students</h4>
        <h2><?php echo $enrolledStudents; ?></h2>
    </div>

    <div class="kpi-card">
        <h4>System Status</h4>
        <h2>Online</h2>
    </div>

</div>

<!-- TABLE -->
<div class="container">

    <div class="card">

        <h3>Student Accounts</h3>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Program</th>
                    <th>Year Level</th>
                </tr>
            </thead>

            <tbody>

            <?php while($row = $resultset->fetch_assoc()): ?>

                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['fullname']; ?></td>
                    <td><?php echo $row['program_name'] ?? 'Not Assigned'; ?></td>
                    <td><?php echo $row['yearlevel']; ?></td>
                </tr>

            <?php endwhile; ?>

            </tbody>
        </table>

    </div>

</div>

</body>
</html>