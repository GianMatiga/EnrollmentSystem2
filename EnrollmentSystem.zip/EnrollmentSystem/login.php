<?php
session_start();
include 'connect.php';

/* =========================
   LOGIN HANDLER
========================= */
if(isset($_POST['login'])){

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    /* =========================
       GET USER (SAFE QUERY)
    ========================= */
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){

        $user = $result->fetch_assoc();

        /* =========================
           VERIFY PASSWORD
        ========================= */
        if(password_verify($password, $user['password'])){

            // SESSION
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['role'] = $user['role'];

            /* =========================
               ROLE REDIRECT
            ========================= */
            if($user['role'] == 'admin'){

                header("Location: admin_dashboard.php");
                exit();

            } elseif($user['role'] == 'dean'){

                header("Location: dean_dashboard.php");
                exit();

            } elseif($user['role'] == 'student'){

                header("Location: student_dashboard.php");
                exit();

            } else {

                echo "<script>alert('Invalid role');</script>";
            }

        } else {

            echo "<script>alert('Wrong Password');</script>";
        }

    } else {

        echo "<script>alert('User not found. Please register first.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Login</title>

<style>
/* (YOUR CSS KEPT EXACTLY THE SAME) */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body{
    min-height: 100vh;
    background: radial-gradient(circle at top, #e0f2fe, #f8fafc, #fefce8);
    display:flex;
    flex-direction:column;
}

.header{
    padding:18px;
    text-align:center;
    font-weight:600;
    background: rgba(255, 230, 0, 0.85);
    backdrop-filter: blur(10px);
    border-bottom: 2px solid rgba(0,0,0,0.05);
}

.wrapper{
    flex:1;
    display:flex;
    justify-content:center;
    align-items:center;
    gap:50px;
    padding:40px;
}

.info-panel{
    width: 520px;
    border-radius: 18px;
    overflow:hidden;
    background:white;
    box-shadow: 0 25px 60px rgba(0,0,0,0.12);
}

.info-panel img{
    width:100%;
    height:280px;
    object-fit:cover;
}

.info-content{
    padding:25px;
}

.info-content h2{
    font-size:24px;
    margin-bottom:10px;
    color:#111827;
}

.info-content p{
    color:#6b7280;
    line-height:1.6;
    margin-bottom:15px;
}

.features{
    background:#f0fdf4;
    border:1px solid #dcfce7;
    padding:15px;
    border-radius:12px;
    color:#16a34a;
    font-size:13px;
}

.login-box{
    width: 380px;
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(12px);
    padding: 35px;
    border-radius: 18px;
    box-shadow: 0 25px 60px rgba(0,0,0,0.15);
}

input{
    width:100%;
    padding:12px;
    margin:6px 0 16px;
    border-radius:10px;
    border:1px solid #e5e7eb;
}

input:focus{
    border-color:#3b82f6;
    box-shadow:0 0 0 4px rgba(59,130,246,0.15);
}

.btn{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#2563eb;
    color:white;
    font-weight:600;
    cursor:pointer;
}

.btn:hover{
    background:#1d4ed8;
}

.back-btn{
    margin-top:10px;
    background:#6b7280;
}
</style>

</head>

<body>

<div class="header">
    Student Registration System
</div>

<div class="wrapper">

    <div class="info-panel">
        <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c">

        <div class="info-content">
            <h2>Secure Academic Portal</h2>
            <p>Role-based login system with dashboards for admin, dean, and students.</p>

            <div class="features">
                ✔ Secure authentication<br>
                ✔ Role-based routing<br>
                ✔ Session management<br>
                ✔ Clean system design
            </div>
        </div>
    </div>

    <div class="login-box">

        <h2>Welcome Back</h2>

        <form method="POST">

            <label>Email</label>
            <input type="email" name="email" required>

            <label>Password</label>
            <input type="password" name="password" required>

            <button type="submit" name="login" class="btn">
                Login
            </button>

        </form>

        <button class="btn back-btn"
        onclick="window.location.href='index.php'">
            Return to Homepage
        </button>

    </div>

</div>

</body>
</html>