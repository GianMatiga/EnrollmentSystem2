<?php
session_start();
include 'connect.php';

/* =========================
   DEAN ONLY ACCESS
========================= */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'dean') {
    header("Location: login.php");
    exit();
}

/* =========================
   CREATE ADMIN ACCOUNT
========================= */
if (isset($_POST['submit'])) {

    $firstname = $_POST['firstname'];
    $lastname  = $_POST['lastname'];
    $email     = $_POST['email'];
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);

    /* CHECK EMAIL */
    $check = $conn->prepare("SELECT id FROM users WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {

        echo "<script>alert('Email already registered');</script>";

    } else {

        /* FULL NAME */
        $fullname = $firstname . " " . $lastname;
        $role = "admin";

        /* INSERT INTO USERS */
        $stmt = $conn->prepare("
            INSERT INTO users (fullname, email, password, role)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("ssss", $fullname, $email, $password, $role);

        if ($stmt->execute()) {

            $user_id = $conn->insert_id;

            /* INSERT INTO ADMIN TABLE */
            $stmt2 = $conn->prepare("
                INSERT INTO tbladmin (user_id)
                VALUES (?)
            ");
            $stmt2->bind_param("i", $user_id);

            if ($stmt2->execute()) {

                echo "<script>
                    alert('Admin created successfully');
                    window.location.href='dean_dashboard.php';
                </script>";

            } else {
                die("tbladmin insert failed: " . $stmt2->error);
            }

        } else {
            die("User insert failed: " . $stmt->error);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dean - Create Admin</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body{
    min-height:100vh;
    background: radial-gradient(circle at top, #e0f2fe, #f8fafc, #fefce8);
}

.header{
    padding:22px;
    text-align:center;
    font-weight:700;
    background: rgba(255, 230, 0, 0.85);
}

.wrapper{
    display:flex;
    justify-content:center;
    align-items:flex-start;
    gap:80px;
    padding:80px 40px;
}

.info-panel{
    width:520px;
    background:white;
    border-radius:20px;
    overflow:hidden;
    box-shadow:0 25px 60px rgba(0,0,0,0.12);
}

.info-panel img{
    width:100%;
    height:300px;
    object-fit:cover;
}

.info-content{
    padding:30px;
}

.features{
    margin-top:18px;
    background:#f0fdf4;
    border:1px solid #dcfce7;
    padding:18px;
    border-radius:12px;
    color:#16a34a;
    font-size:13px;
}

.register-box{
    width:420px;
    background:rgba(255,255,255,0.92);
    padding:45px;
    border-radius:20px;
    box-shadow:0 25px 60px rgba(0,0,0,0.15);
}

label{
    display:block;
    margin-top:18px;
    margin-bottom:6px;
    font-weight:600;
}

input{
    width:100%;
    padding:14px;
    border-radius:12px;
    border:1px solid #e5e7eb;
}

.btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:12px;
    background:#2563eb;
    color:white;
    font-weight:600;
    margin-top:25px;
    cursor:pointer;
}

.btn:hover{
    background:#1d4ed8;
}

.back-btn{
    background:#6b7280;
    margin-top:12px;
}
</style>

</head>

<body>

<div class="header">
    DEAN - Create Admin Account
</div>

<div class="wrapper">

<!-- LEFT PANEL -->
<div class="info-panel">
    <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644">

    <div class="info-content">
        <h2>Admin Management</h2>
        <p>Create admin accounts with secure role-based access control.</p>

        <div class="features">
            ✔ users table insert<br>
            ✔ tbladmin insert<br>
            ✔ role-based system<br>
            ✔ dean-controlled access
        </div>
    </div>
</div>

<!-- FORM -->
<div class="register-box">

<h2>Create Admin</h2>

<form method="POST">

    <label>First Name</label>
    <input type="text" name="firstname" required>

    <label>Last Name</label>
    <input type="text" name="lastname" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <button type="submit" name="submit" class="btn">
        Create Admin
    </button>

</form>

<button class="btn back-btn"
onclick="window.location.href='dean_dashboard.php'">
    Back
</button>

</div>

</div>

</body>
</html>