<?php
session_start();
include 'connect.php';

/* =========================
   DEAN ONLY ACCESS
========================= */
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'dean'){
    header("Location: login.php");
    exit();
}

/* =========================
   CREATE STUDENT ACCOUNT
========================= */
if(isset($_POST['submit'])){

    $firstname = $_POST['firstname'];
    $lastname  = $_POST['lastname'];
    $email     = $_POST['email'];
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $program_id = $_POST['program'];
    $yearlevel  = $_POST['yearlevel'];

    /* CHECK EMAIL */
    $check = $conn->prepare("SELECT id FROM users WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if($result->num_rows > 0){
        echo "<script>alert('Email already registered');</script>";
    } else {

        /* FULL NAME FOR USERS TABLE */
        $fullname = $firstname . " " . $lastname;
        $role = "student";

        /* INSERT INTO USERS */
        $stmt = $conn->prepare("
            INSERT INTO users (fullname, email, password, role)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("ssss", $fullname, $email, $password, $role);

        if($stmt->execute()){

            $user_id = $conn->insert_id;

            /* INSERT INTO STUDENT TABLE (NOW WITH FIRST + LAST NAME) */
            $stmt2 = $conn->prepare("
                INSERT INTO tblstudent 
                (user_id, firstname, lastname, program_id, yearlevel)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt2->bind_param(
                "issii",
                $user_id,
                $firstname,
                $lastname,
                $program_id,
                $yearlevel
            );

            if($stmt2->execute()){

                echo "<script>
                    alert('Student created successfully');
                    window.location.href='dean_dashboard.php';
                </script>";

            } else {
                die("tblstudent insert failed: " . $stmt2->error);
            }

        } else {
            die("User insert failed: " . $stmt->error);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dean - Create Student</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body{
    min-height:100vh;
    background: radial-gradient(circle at top, #e0f2fe, #f8fafc, #fefce8);
}

.header{
    padding:22px;
    text-align:center;
    font-weight:700;
    background: rgba(255, 230, 0, 0.85);
}

.wrapper{
    display:flex;
    justify-content:center;
    align-items:flex-start;
    gap:80px;
    padding:80px 40px;
}

.info-panel{
    width:520px;
    background:white;
    border-radius:20px;
    overflow:hidden;
    box-shadow:0 25px 60px rgba(0,0,0,0.12);
}

.info-panel img{
    width:100%;
    height:300px;
    object-fit:cover;
}

.info-content{
    padding:30px;
}

.features{
    margin-top:18px;
    background:#f0fdf4;
    border:1px solid #dcfce7;
    padding:18px;
    border-radius:12px;
    color:#16a34a;
    font-size:13px;
}

.register-box{
    width:420px;
    background:rgba(255,255,255,0.92);
    padding:45px;
    border-radius:20px;
    box-shadow:0 25px 60px rgba(0,0,0,0.15);
}

label{
    display:block;
    margin-top:18px;
    margin-bottom:6px;
    font-weight:600;
}

input, select{
    width:100%;
    padding:14px;
    border-radius:12px;
    border:1px solid #e5e7eb;
}

.btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:12px;
    background:#2563eb;
    color:white;
    font-weight:600;
    margin-top:25px;
    cursor:pointer;
}

.btn:hover{
    background:#1d4ed8;
}

.back-btn{
    background:#6b7280;
    margin-top:12px;
}
</style>

</head>

<body>

<div class="header">
    DEAN - Create Student Account
</div>

<div class="wrapper">

<div class="info-panel">
    <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644">

    <div class="info-content">
        <h2>Student Management</h2>
        <p>Create students with program & year level linked to database.</p>

        <div class="features">
            ✔ users table insert<br>
            ✔ tblstudent insert<br>
            ✔ firstname + lastname stored<br>
            ✔ dean-controlled system
        </div>
    </div>
</div>

<div class="register-box">

<h2>Create Student</h2>

<form method="POST">

    <label>First Name</label>
    <input type="text" name="firstname" required>

    <label>Last Name</label>
    <input type="text" name="lastname" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <label>Program</label>
    <select name="program" required>
        <option value="">Select Program</option>
        <option value="1">BSIT</option>
        <option value="2">BSCS</option>
    </select>

    <label>Year Level</label>
    <select name="yearlevel" required>
        <option value="">Select Year</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
    </select>

    <button type="submit" name="submit" class="btn">
        Create Student
    </button>

</form>

<button class="btn back-btn"
onclick="window.location.href='dean_dashboard.php'">
    Back
</button>

</div>

</div>

</body>
</html>