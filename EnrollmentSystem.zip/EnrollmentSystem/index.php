<?php include 'connect.php'; ?>

<!DOCTYPE html>
<html>
<head>

<title>Student Registration System</title>

<style>

/* =========================
   BASE
========================= */
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body{
    background: #f4f6f9;
    color: #222;
}

/* =========================
   NAVBAR
========================= */
.navbar{
    background: linear-gradient(90deg, #ffe600, #ffd000);
    padding: 18px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 3px solid #d6d600;
}

.navbar h2{
    font-size: 20px;
}

.nav-buttons a{
    text-decoration: none;
    margin-left: 10px;
}

.nav-buttons button{
    padding: 10px 18px;
    border: none;
    border-radius: 6px;
    background: #007bff;
    color: white;
    cursor: pointer;
    transition: 0.2s;
}

.nav-buttons button:hover{
    background: #0056b3;
}

/* =========================
   HERO
========================= */
.hero{
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 70px 40px;
    background: linear-gradient(to right, #ffffff, #f1f5ff);
}

.hero-container{
    max-width: 1200px;
    display: flex;
    gap: 50px;
    align-items: center;
}

.hero-text{
    flex: 1;
    animation: fadeLeft 0.8s ease;
}

.hero-text h1{
    font-size: 48px;
    margin-bottom: 15px;
}

.hero-text p{
    font-size: 18px;
    color: #555;
    line-height: 1.6;
    margin-bottom: 25px;
}

.hero-text button{
    padding: 14px 28px;
    border: none;
    border-radius: 6px;
    background: #007bff;
    color: white;
    font-size: 16px;
    cursor: pointer;
    transition: 0.2s;
}

.hero-text button:hover{
    transform: scale(1.05);
}

/* IMAGE */
.hero-image{
    flex: 1;
    text-align: center;
}

.hero-image img{
    width: 100%;
    max-width: 420px;
}

/* =========================
   FEATURES SECTION
========================= */
.features{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    padding: 60px 40px;
    max-width: 1200px;
    margin: auto;
}

.feature-card{
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    transition: 0.3s;
}

.feature-card:hover{
    transform: translateY(-5px);
}

.feature-card h3{
    margin-bottom: 10px;
    color: #007bff;
}

.feature-card p{
    color: #666;
    font-size: 14px;
    line-height: 1.5;
}

/* =========================
   ABOUT SECTION (CONVINCING PART)
========================= */
.about{
    background: #fff;
    padding: 70px 40px;
    text-align: center;
}

.about h2{
    font-size: 32px;
    margin-bottom: 15px;
}

.about p{
    max-width: 800px;
    margin: auto;
    color: #555;
    line-height: 1.7;
    font-size: 16px;
}

/* =========================
   CALL TO ACTION
========================= */
.cta{
    background: linear-gradient(90deg, #007bff, #0056b3);
    color: white;
    text-align: center;
    padding: 60px 20px;
}

.cta h2{
    font-size: 30px;
    margin-bottom: 10px;
}

.cta p{
    margin-bottom: 20px;
    opacity: 0.9;
}

.cta button{
    padding: 14px 28px;
    border: none;
    border-radius: 6px;
    background: white;
    color: #007bff;
    font-weight: bold;
    cursor: pointer;
    transition: 0.2s;
}

.cta button:hover{
    transform: scale(1.05);
}

/* =========================
   ANIMATIONS
========================= */
@keyframes fadeLeft{
    from{opacity:0; transform: translateX(-30px);}
    to{opacity:1; transform: translateX(0);}
}

/* =========================
   RESPONSIVE
========================= */
@media(max-width: 900px){
    .hero-container{
        flex-direction: column;
        text-align: center;
    }

    .features{
        grid-template-columns: 1fr;
    }
}

</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">

    <h2>Student Registration System</h2>

    <div class="nav-buttons">

        <a href="login.php"><button>Login</button></a>
        

    </div>

</div>

<!-- HERO -->
<div class="hero">

    <div class="hero-container">

        <div class="hero-text">

            <h1>
                Manage Students<br>
                Smarter & Faster
            </h1>

            <p>
                A modern student registration system designed to simplify enrollment,
                record keeping, and academic management in one secure platform.
            </p>

            <a href="login.php">
                <button>Get Started</button>
            </a>

        </div>

        <div class="hero-image">

            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135755.png">

        </div>

    </div>

</div>

<!-- FEATURES -->
<div class="features">

    <div class="feature-card">
        <h3>📚 Student Records</h3>
        <p>Store and manage student information in a structured and secure system.</p>
    </div>

    <div class="feature-card">
        <h3>⚡ Fast Enrollment</h3>
        <p>Quickly register students and assign courses without delays or confusion.</p>
    </div>

    <div class="feature-card">
        <h3>🔒 Secure System</h3>
        <p>User authentication ensures only authorized access to sensitive data.</p>
    </div>

</div>

<!-- ABOUT -->
<div class="about">

    <h2>Why This System Exists</h2>

    <p>
        Many schools still rely on manual or outdated systems that slow down enrollment and increase errors.
        This system was designed to centralize student data, reduce workload, and improve accuracy in school management.
        It is simple enough for beginners but powerful enough for real academic use.
    </p>

</div>

<!-- CTA -->
<div class="cta">

    <h2>Start Managing Students Efficiently Today</h2>

    <p>Join the system and experience faster, cleaner, and smarter registration.</p>

    <a href="login.php">
        <button>Access System</button>
    </a>

</div>

</body>
</html>