<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================
   ROLE-BASED HOME LINK
========================= */
$homeLink = "home.php"; // default

if(isset($_SESSION['role'])){

    if($_SESSION['role'] == 'admin'){
        $homeLink = "admin_dashboard.php";

    } elseif($_SESSION['role'] == 'dean'){
        $homeLink = "dean_dashboard.php";

    } elseif($_SESSION['role'] == 'student'){
        $homeLink = "student_dashboard.php";
    }
}
?>

<!doctype html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="css/site.css"/>

    <title>SIS - <?php echo $title ?? 'System'; ?></title>

</head>

<body>

<div class="container">

<nav class="navbar navbar-expand-lg navbar-light bg-light">

    <!-- LOGO -->
    <a class="navbar-brand" href="<?php echo $homeLink; ?>">
        <img src="images/logosrp.png" width="50" height="40">
    </a>

    <button class="navbar-toggler" type="button" data-toggle="collapse"
        data-target="#navbarSupportedContent">

        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <ul class="navbar-nav mr-auto">

            <!-- HOME (ROLE BASED) -->
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo $homeLink; ?>">
                    Home <span class="sr-only">(current)</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#">About</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#">Contact Us</a>
            </li>

            <li class="nav-item dropdown">

                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">
                    Menu
                </a>

                <div class="dropdown-menu">

                    <a class="dropdown-item" href="login.php">Login</a>
                    <a class="dropdown-item" href="registration.php">User Registration Page</a>
                    <a class="dropdown-item" href="<?php echo $homeLink; ?>">Dashboard</a>

                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item" href="#">Something else here</a>

                </div>
            </li>

        </ul>

        <!-- SEARCH -->
        <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                Search
            </button>
        </form>

    </div>

</nav>