<?php

include 'connect.php';

/* =========================
   CHECK LOGIN SESSION
========================= */
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit();
}

/* =========================
   FETCH USER FROM DB (VALIDATION LAYER)
========================= */
$user_id = $_SESSION['user_id'];

$result = $conn->query("
    SELECT * FROM users 
    WHERE id = '$user_id'
    LIMIT 1
");

if ($result->num_rows == 0) {
    // invalid session user
    session_destroy();
    header("Location: login.php");
    exit();
}

$user = $result->fetch_assoc();

/* =========================
   SYNC ROLE (SECURITY CHECK)
========================= */
if ($_SESSION['role'] !== $user['role']) {
    session_destroy();
    header("Location: login.php");
    exit();
}

?>