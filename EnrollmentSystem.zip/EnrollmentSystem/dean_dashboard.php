<?php
session_start();
require_once 'connect.php';
require_once 'includes/header.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'dean'){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

/* DEAN INFO */
$stmt = $conn->prepare("SELECT fullname FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$dean = $stmt->get_result()->fetch_assoc();
$dean_name = $dean['fullname'] ?? 'Dean';

/* DATA */
$admins = $conn->query("SELECT * FROM users WHERE role='admin'");

$students = $conn->query("
    SELECT u.id, u.fullname, t.yearlevel, p.program_name
    FROM users u
    LEFT JOIN tblstudent t ON u.id = t.user_id
    LEFT JOIN tblprogram p ON t.program_id = p.program_id
    WHERE u.role='student'
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Dean Dashboard</title>

<style>

/* BACKGROUND */
body{
    font-family: Arial;
    margin:0;
    background: linear-gradient(-45deg,#f4f6f9,#e0f2fe,#fefce8,#e2e8f0);
    background-size:400% 400%;
    animation:bgMove 12s ease infinite;
}

@keyframes bgMove{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
}

/* TOPBAR */
.topbar{
    background: linear-gradient(90deg,#ffe600,#ffd000);
    padding:18px 50px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.topbar h2{
    margin:0;
}

/* BUTTONS */
.btn{
    padding:10px 14px;
    border-radius:8px;
    text-decoration:none;
    color:white;
    font-size:13px;
    display:inline-block;
    transition:0.2s;
}

.btn:hover{
    transform:translateY(-2px);
}

/* COLORS */
.btn-add{background:#007bff;}
.btn-add2{background:#16a34a;}
.btn-del{background:#dc2626;}
.btn-edit{background:#16a34a;}
.btn-logout{background:#6c757d;}

/* CENTER LAYOUT */
.container{
    max-width:1100px;
    margin:40px auto;
    padding:0 20px;
}

/* ACTION BAR */
.top-actions{
    display:flex;
    justify-content:flex-end;
    gap:10px;
    margin-bottom:20px;
}

/* CARDS */
.card{
    background:white;
    padding:25px;
    border-radius:14px;
    margin-bottom:25px;
    box-shadow:0 10px 25px rgba(0,0,0,0.06);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    table-layout:fixed;
}

th{
    background:#007bff;
    color:white;
    padding:14px;
    text-align:left;
}

td{
    padding:14px;
    border-bottom:1px solid #eee;
}

/* ACTION GROUP */
.action-group{
    display:flex;
    gap:6px;
}

</style>
</head>

<body>

<!-- TOPBAR -->
<div class="topbar">
    <h2>Dean Dashboard</h2>
    <div>
        Welcome, <b><?php echo $dean_name; ?></b>
        <a class="btn btn-logout" href="logout.php">Logout</a>
    </div>
</div>

<div class="container">

    <!-- ACTION BUTTONS -->
    <div class="top-actions">

        <a class="btn btn-add" href="dean_add_student.php">
            + Add Student
        </a>

        <a class="btn btn-add2" href="dean_add_admin.php">
            + Add Admin
        </a>

    </div>

    <!-- ADMINS TABLE -->
    <div class="card">
        <h3>Admins</h3>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>

            <?php while($a = $admins->fetch_assoc()): ?>
            <tr>
                <td><?php echo $a['id']; ?></td>
                <td><?php echo $a['fullname']; ?></td>
                <td><?php echo $a['email']; ?></td>
                <td>
                    <div class="action-group">
                        <a class="btn btn-edit" href="dean_update_admin.php?id=<?php echo $a['id']; ?>">Edit</a>
                        <a class="btn btn-del" href="delete.php?id=<?php echo $a['id']; ?>" onclick="return confirm('Delete this admin?')">Delete</a>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>

        </table>
    </div>

    <!-- STUDENTS TABLE -->
    <div class="card">
        <h3>Students</h3>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Program</th>
                <th>Year Level</th>
                <th>Action</th>
            </tr>

            <?php while($s = $students->fetch_assoc()): ?>
            <tr>
                <td><?php echo $s['id']; ?></td>
                <td><?php echo $s['fullname']; ?></td>
                <td><?php echo $s['program_name'] ?? 'Not Set'; ?></td>
                <td><?php echo $s['yearlevel'] ?? '-'; ?></td>
                <td>
                    <div class="action-group">
                        <a class="btn btn-edit" href="dean_update_student.php?id=<?php echo $s['id']; ?>">Edit</a>
                        <a class="btn btn-del" href="delete_student.php?id=<?php echo $s['id']; ?>" onclick="return confirm('Delete this student?')">Delete</a>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>

        </table>
    </div>

</div>

</body>
</html>