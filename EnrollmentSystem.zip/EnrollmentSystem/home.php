<?php

include 'connect.php';
require_once 'includes/header.php';

if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit();
}

$totalStudents = $conn->query("SELECT COUNT(*) as total FROM tblstudent")->fetch_assoc()['total'];
$totalUsers = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$totalCourses = $conn->query("SELECT COUNT(DISTINCT program) as total FROM tblstudent")->fetch_assoc()['total'];

?>

<!DOCTYPE html>
<html>
<head>

<title>Dashboard</title>

<style>

/* =========================
   BACKGROUND (MORE PREMIUM)
========================= */
body{
    margin: 0;
    font-family: "Segoe UI", Arial;
    background: radial-gradient(circle at top, #e0f2fe, #f8fafc, #eef2ff);
    min-height: 100vh;
}

/* =========================
   HEADER
========================= */
.header{
    background: linear-gradient(90deg, #facc15, #fde047);
    padding: 18px;
    text-align: center;
    font-weight: 700;
    letter-spacing: 0.5px;
    box-shadow: 0 10px 20px rgba(0,0,0,0.08);
}

/* =========================
   LAYOUT
========================= */
.container{
    max-width: 1200px;
    margin: 40px auto;
    padding: 20px;
}

/* =========================
   HERO SECTION (STRONG VISUAL)
========================= */
.hero{
    background: linear-gradient(135deg, #2563eb, #1e40af);
    color: white;
    border-radius: 18px;
    padding: 35px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 25px 60px rgba(0,0,0,0.2);
    margin-bottom: 25px;
}

.hero-text h1{
    margin: 0;
    font-size: 28px;
}

.hero-text p{
    margin-top: 10px;
    opacity: 0.9;
    line-height: 1.6;
}

.hero img{
    width: 180px;
    border-radius: 12px;
}

/* =========================
   KPI SECTION (BIG AND VISUAL)
========================= */
.kpi-grid{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}

.kpi{
    background: white;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.08);
    transition: 0.3s;
    position: relative;
    overflow: hidden;
}

.kpi:hover{
    transform: translateY(-6px);
}

.kpi h2{
    margin: 0;
    font-size: 32px;
    color: #1d4ed8;
}

.kpi p{
    margin-top: 8px;
    color: #6b7280;
    font-size: 14px;
}

/* decorative glow */
.kpi::after{
    content: "";
    position: absolute;
    width: 120px;
    height: 120px;
    background: rgba(59,130,246,0.15);
    border-radius: 50%;
    top: -30px;
    right: -30px;
}

/* =========================
   MAIN GRID
========================= */
.grid{
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 20px;
}

/* =========================
   INFO PANEL
========================= */
.panel{
    background: white;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.08);
}

.panel h3{
    margin-top: 0;
}

.panel p{
    color: #6b7280;
    line-height: 1.6;
}

/* =========================
   ACTION CARDS (VISUAL)
========================= */
.action{
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.action-card{
    background: linear-gradient(135deg, #ffffff, #f8fafc);
    border: 1px solid #e5e7eb;
    padding: 18px;
    border-radius: 14px;
    transition: 0.3s;
}

.action-card:hover{
    transform: scale(1.02);
    border-color: #93c5fd;
}

.action-card h4{
    margin: 0;
}

.action-card p{
    font-size: 13px;
    color: #6b7280;
}

/* BUTTON */
.btn{
    display: inline-block;
    margin-top: 10px;
    padding: 9px 14px;
    background: #2563eb;
    color: white;
    text-decoration: none;
    border-radius: 10px;
    font-size: 13px;
}

/* =========================
   RESPONSIVE
========================= */
@media(max-width: 900px){
    .hero{
        flex-direction: column;
        text-align: center;
    }

    .kpi-grid,
    .grid{
        grid-template-columns: 1fr;
    }
}

</style>

</head>

<body>

<div class="header">
    Student Registration System Dashboard
</div>

<div class="container">

    <!-- HERO -->
    <div class="hero">

        <div class="hero-text">

            <h1>Welcome Back, <?php echo $_SESSION['user']; ?> 👋</h1>

            <p>
                Manage students, monitor academic records, and handle enrollment
                operations in a centralized, modern system designed for efficiency
                and clarity.
            </p>

        </div>

        <img src="https://cdn-icons-png.flaticon.com/512/3135/3135755.png">

    </div>

    <!-- KPI -->
    <div class="kpi-grid">

        <div class="kpi">
            <h2><?php echo $totalStudents; ?></h2>
            <p>Total Students Registered</p>
        </div>

        <div class="kpi">
            <h2><?php echo $totalUsers; ?></h2>
            <p>System Users</p>
        </div>

        <div class="kpi">
            <h2><?php echo $totalCourses; ?></h2>
            <p>Active Programs</p>
        </div>

    </div>

    <!-- MAIN -->
    <div class="grid">

        <!-- LEFT PANEL -->
        <div class="panel">

            <h3>System Overview</h3>

            <p>
                This platform provides structured management for student data,
                ensuring fast access, organized records, and simplified enrollment workflows.
                Built for scalability and ease of use in academic environments.
            </p>

            <p>
                Use the tools on the right to manage records or add new students instantly.
            </p>

        </div>

        <!-- RIGHT ACTIONS -->
        <div class="action">

            <div class="action-card">
                <h4>Student Records</h4>
                <p>View and manage all registered students.</p>
                <a class="btn" href="dashboard.php">Open</a>
            </div>

            <div class="action-card">
                <h4>Add Student</h4>
                <p>Register new student into the system.</p>
                <a class="btn" href="register.php">Add</a>
            </div>

            <div class="action-card">
                <h4>Logout</h4>
                <p>Securely exit your session.</p>
                <a class="btn" href="logout.php">Logout</a>
            </div>

        </div>

    </div>

</div>

</body>
</html>