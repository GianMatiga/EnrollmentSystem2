<?php
include 'connect.php';

if(isset($_GET['id'])){

    $id = $_GET['id'];

    if(!is_numeric($id)){
        echo "<script>
                alert('Invalid ID');
                window.location.href='dean_dashboard.php';
              </script>";
        exit();
    }

    /* =========================
       1. DELETE FROM tbladmin FIRST
    ========================= */
    $stmt1 = $conn->prepare("DELETE FROM tbladmin WHERE user_id = ?");
    $stmt1->bind_param("i", $id);
    $stmt1->execute();
    $stmt1->close();

    /* =========================
       2. DELETE FROM users TABLE
    ========================= */
    $stmt2 = $conn->prepare("DELETE FROM users WHERE id = ? AND role='admin'");
    $stmt2->bind_param("i", $id);

    if($stmt2->execute()){

        echo "<script>
                alert('Admin deleted successfully.');
                window.location.href='dean_dashboard.php';
              </script>";

    } else {

        echo "<script>
                alert('Failed to delete admin.');
                window.location.href='dean_dashboard.php';
              </script>";
    }

    $stmt2->close();

} else {

    echo "<script>
            alert('No ID provided.');
            window.location.href='dean_dashboard.php';
          </script>";
}
?>