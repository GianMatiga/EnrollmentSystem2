<?php

include 'connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$role = $_SESSION['role'] ?? '';
$user_id = $_SESSION['user_id'] ?? 0;

/* =========================
   BASE QUERY
========================= */
$baseQuery = "
SELECT 
    tblstudent.student_id,
    tblstudent.firstname,
    tblstudent.lastname,
    tblstudent.yearlevel,
    tblstudent.user_id,
    tblprogram.program_name
FROM tblstudent
LEFT JOIN tblprogram 
    ON tblstudent.program_id = tblprogram.program_id
";

/* =========================
   ROLE FILTERING
========================= */

if ($role == 'admin') {

    // ADMIN → sees ALL students
    $query = $baseQuery;
}

/* =========================
   DEAN → only students under their programs
========================= */
elseif ($role == 'dean') {

    $query = $baseQuery . "
    INNER JOIN tblprogram 
        ON tblstudent.program_id = tblprogram.program_id
    INNER JOIN tbldean 
        ON tblprogram.dean_id = tbldean.dean_id
    WHERE tbldean.user_id = ?
    ";
}

/* =========================
   STUDENT → only their own record
========================= */
else {

    $query = $baseQuery . "
    WHERE tblstudent.user_id = ?
    ";
}

/* =========================
   EXECUTE QUERY SAFELY
========================= */

if ($role == 'student') {

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $resultset = $stmt->get_result();

} elseif ($role == 'dean') {

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $resultset = $stmt->get_result();

} else {

    $resultset = $conn->query($query);
}

/* =========================
   ERROR CHECK
========================= */
if (!$resultset) {
    die("Query Failed: " . $conn->error);
}

?>