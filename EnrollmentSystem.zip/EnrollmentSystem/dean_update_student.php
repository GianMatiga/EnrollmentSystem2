<?php
session_start();
include 'connect.php';

/* =========================
   DEAN ONLY ACCESS
========================= */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'dean') {
    header("Location: login.php");
    exit();
}

/* =========================
   GET STUDENT ID
========================= */
$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: dean_dashboard.php");
    exit();
}

/* =========================
   FETCH CURRENT DATA
========================= */
$stmt = $conn->prepare("
    SELECT 
        u.id,
        u.fullname,
        u.email,
        t.firstname,
        t.lastname,
        t.program_id,
        t.yearlevel
    FROM users u
    LEFT JOIN tblstudent t ON u.id = t.user_id
    WHERE u.id = ? AND u.role='student'
");

$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    die("Student not found");
}

/* =========================
   PROGRAMS
========================= */
$programs = $conn->query("SELECT * FROM tblprogram");

/* =========================
   UPDATE HANDLER
========================= */
if (isset($_POST['update'])) {

    $firstname = $_POST['firstname'];
    $lastname  = $_POST['lastname'];
    $email     = $_POST['email'];
    $program_id = $_POST['program'];
    $yearlevel = $_POST['yearlevel'];

    $fullname = $firstname . " " . $lastname;

    /* UPDATE USERS */
    $stmt1 = $conn->prepare("
        UPDATE users 
        SET fullname=?, email=? 
        WHERE id=?
    ");
    $stmt1->bind_param("ssi", $fullname, $email, $id);
    $stmt1->execute();

    /* UPDATE STUDENT TABLE */
    $stmt2 = $conn->prepare("
        UPDATE tblstudent 
        SET firstname=?, lastname=?, program_id=?, yearlevel=?
        WHERE user_id=?
    ");

    $stmt2->bind_param(
        "ssiii",
        $firstname,
        $lastname,
        $program_id,
        $yearlevel,
        $id
    );

    if ($stmt2->execute()) {

        echo "<script>
            alert('Student updated successfully');
            window.location.href='dean_dashboard.php';
        </script>";
        exit();

    } else {
        echo "<script>alert('Update failed');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dean - Update Student</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body{
    min-height:100vh;
    background: radial-gradient(circle at top, #e0f2fe, #f8fafc, #fefce8);
}

/* HEADER */
.header{
    padding:22px;
    text-align:center;
    font-weight:700;
    background: rgba(255, 230, 0, 0.85);
}

/* LAYOUT */
.wrapper{
    display:flex;
    justify-content:center;
    align-items:flex-start;
    gap:80px;
    padding:80px 40px;
}

/* PANEL */
.info-panel{
    width:520px;
    background:white;
    border-radius:20px;
    overflow:hidden;
    box-shadow:0 25px 60px rgba(0,0,0,0.12);
}

.info-panel img{
    width:100%;
    height:300px;
    object-fit:cover;
}

.info-content{
    padding:30px;
}

.register-box{
    width:420px;
    background:rgba(255,255,255,0.92);
    padding:45px;
    border-radius:20px;
    box-shadow:0 25px 60px rgba(0,0,0,0.15);
}

label{
    display:block;
    margin-top:18px;
    margin-bottom:6px;
    font-weight:600;
}

input, select{
    width:100%;
    padding:14px;
    border-radius:12px;
    border:1px solid #e5e7eb;
}

/* BUTTON */
.btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:12px;
    background:#2563eb;
    color:white;
    font-weight:600;
    margin-top:25px;
    cursor:pointer;
}

.btn:hover{
    background:#1d4ed8;
}

.back-btn{
    background:#6b7280;
    margin-top:12px;
}
</style>

</head>

<body>

<div class="header">
    DEAN - Update Student Account
</div>

<div class="wrapper">

<!-- LEFT PANEL -->
<div class="info-panel">
    <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644">

    <div class="info-content">
        <h2>Update Student Record</h2>
        <p>Edit student details including program and year level.</p>
    </div>
</div>

<!-- FORM -->
<div class="register-box">

<h2>Update Student</h2>

<form method="POST">

    <label>First Name</label>
    <input type="text" name="firstname"
        value="<?= htmlspecialchars($data['firstname']) ?>" required>

    <label>Last Name</label>
    <input type="text" name="lastname"
        value="<?= htmlspecialchars($data['lastname']) ?>" required>

    <label>Email</label>
    <input type="email" name="email"
        value="<?= htmlspecialchars($data['email']) ?>" required>

    <label>Program</label>
    <select name="program" required>
        <?php while($p = $programs->fetch_assoc()): ?>
            <option value="<?= $p['program_id'] ?>"
                <?= $p['program_id'] == $data['program_id'] ? 'selected' : '' ?>>
                <?= $p['program_name'] ?>
            </option>
        <?php endwhile; ?>
    </select>

    <label>Year Level</label>
    <select name="yearlevel" required>
        <option value="1" <?= $data['yearlevel']==1?'selected':'' ?>>1</option>
        <option value="2" <?= $data['yearlevel']==2?'selected':'' ?>>2</option>
        <option value="3" <?= $data['yearlevel']==3?'selected':'' ?>>3</option>
        <option value="4" <?= $data['yearlevel']==4?'selected':'' ?>>4</option>
    </select>

    <button type="submit" name="update" class="btn">
        Update Student
    </button>

</form>

<button class="btn back-btn"
onclick="window.location.href='dean_dashboard.php'">
    Back
</button>

</div>

</div>

</body>
</html>