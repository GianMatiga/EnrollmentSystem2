<?php
session_start();
include 'connect.php';

/* =========================
   SUBMIT HANDLER
========================= */
if(isset($_POST['submit'])){

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    /* =========================
       CHECK IF EMAIL EXISTS
    ========================= */
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){

        echo "<script>alert('Email already exists');</script>";

    } else {

        /* =========================
           INSERT USER
        ========================= */
        $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fullname, $email, $password, $role);

        if($stmt->execute()){

            $user_id = $conn->insert_id;

            /* =========================
               INSERT INTO ROLE TABLES
            ========================= */
            if($role == "admin"){

                $conn->query("INSERT INTO tbladmin (user_id) VALUES ($user_id)");

            } elseif($role == "dean"){

                $conn->query("INSERT INTO tbldean (user_id) VALUES ($user_id)");
            }

            /* =========================
               SUCCESS → REDIRECT LOGIN
            ========================= */
            echo "<script>
                    alert('User created successfully!');
                    window.location.href='login.php';
                  </script>";
            exit();

        } else {
            echo "<script>alert('Error creating user');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Secret User Registration</title>

<style>

/* =========================
   DESIGN (UNCHANGED STYLE)
========================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body{
    min-height:100vh;
    background: radial-gradient(circle at top, #e0f2fe, #f8fafc, #fefce8);
    display:flex;
    flex-direction:column;
}

.header{
    padding:18px;
    text-align:center;
    font-weight:600;
    background: rgba(255, 230, 0, 0.85);
    backdrop-filter: blur(10px);
    border-bottom: 2px solid rgba(0,0,0,0.05);
}

.wrapper{
    flex:1;
    display:flex;
    justify-content:center;
    align-items:center;
    gap:50px;
    padding:40px;
}

.info-panel{
    width:520px;
    background:white;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 25px 60px rgba(0,0,0,0.12);
}

.info-panel img{
    width:100%;
    height:280px;
    object-fit:cover;
}

.info-content{
    padding:25px;
}

.info-content h2{
    font-size:24px;
    margin-bottom:10px;
    color:#111827;
}

.info-content p{
    color:#6b7280;
    line-height:1.6;
    margin-bottom:15px;
}

.features{
    background:#f0fdf4;
    border:1px solid #dcfce7;
    padding:15px;
    border-radius:12px;
    color:#16a34a;
    font-size:13px;
    line-height:1.8;
}

.register-box{
    width:380px;
    background:rgba(255,255,255,0.9);
    backdrop-filter: blur(12px);
    padding:35px;
    border-radius:18px;
    box-shadow:0 25px 60px rgba(0,0,0,0.15);
}

.register-box h2{
    font-size:22px;
    margin-bottom:6px;
}

.subtitle{
    font-size:13px;
    color:#6b7280;
    margin-bottom:18px;
}

.form-group{
    margin-bottom:14px;
}

label{
    font-size:13px;
    font-weight:600;
    color:#374151;
}

input, select{
    width:100%;
    padding:12px;
    margin-top:6px;
    border-radius:10px;
    border:1px solid #e5e7eb;
    outline:none;
}

input:focus, select:focus{
    border-color:#3b82f6;
    box-shadow:0 0 0 4px rgba(59,130,246,0.15);
}

.btn{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#2563eb;
    color:white;
    font-weight:600;
    cursor:pointer;
}

.btn:hover{
    background:#1d4ed8;
}

.back-btn{
    background:#6b7280;
    margin-top:10px;
}

.security-note{
    text-align:center;
    margin-top:15px;
    font-size:11px;
    color:#9ca3af;
}

</style>

</head>

<body>

<div class="header">
    🔐 Secure Admin/Dean Account Creation
</div>

<div class="wrapper">

    <!-- LEFT PANEL -->
    <div class="info-panel">

        <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644">

        <div class="info-content">

            <h2>Role-Based User System</h2>

            <p>
                This panel allows authorized users to create admin and dean accounts
                while automatically storing records in relational database tables.
            </p>

            <div class="features">
                ✔ Users table integration<br>
                ✔ Role-based table separation<br>
                ✔ Secure password hashing<br>
                ✔ Relational database structure
            </div>

        </div>

    </div>

    <!-- FORM -->
    <div class="register-box">

        <h2>Create User</h2>
        <div class="subtitle">Add admin or dean accounts</div>

        <form method="POST">

            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="fullname" required>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>

            <div class="form-group">
                <label>Role</label>
                <select name="role" required>
                    <option value="admin">Admin</option>
                    <option value="dean">Dean</option>
                </select>
            </div>

            <button type="submit" name="submit" class="btn">
                Create Account
            </button>

        </form>

        <button class="btn back-btn"
        onclick="window.location.href='login.php'">
            Back
        </button>

        <div class="security-note">
            System records are automatically stored in relational tables
        </div>

    </div>

</div>

</body>
</html>