<?php
session_start();
include 'connect.php';
require_once 'includes/header.php';
/* =========================
   DEAN ONLY ACCESS
========================= */
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'dean'){
    header("Location: login.php");
    exit();
}

$user_id = $_GET['id'] ?? null;

if(!$user_id){
    header("Location: dean_dashboard.php");
    exit();
}

/* =========================
   GET USER DATA
========================= */
$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if(!$user){
    die("User not found");
}

/* =========================
   UPDATE HANDLER
========================= */
if(isset($_POST['update'])){

    $fullname = $_POST['fullname'];
    $email    = $_POST['email'];
    $role     = $_POST['role'];

    if(!empty($_POST['password'])){
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $stmt = $conn->prepare("
            UPDATE users 
            SET fullname=?, email=?, password=?, role=? 
            WHERE id=?
        ");
        $stmt->bind_param("ssssi", $fullname, $email, $password, $role, $user_id);
    } else {
        $stmt = $conn->prepare("
            UPDATE users 
            SET fullname=?, email=?, role=? 
            WHERE id=?
        ");
        $stmt->bind_param("sssi", $fullname, $email, $role, $user_id);
    }

    if($stmt->execute()){

        // SYNC ROLE TABLES (IMPORTANT)
        $conn->query("DELETE FROM tbladmin WHERE user_id=$user_id");
        $conn->query("DELETE FROM tbldean WHERE user_id=$user_id");

        if($role === "admin"){
            $conn->query("INSERT INTO tbladmin (user_id) VALUES ($user_id)");
        }

        if($role === "dean"){
            $conn->query("INSERT INTO tbldean (user_id) VALUES ($user_id)");
        }

        echo "<script>
            alert('User updated successfully');
            window.location.href='dean_dashboard.php';
        </script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Update User</title>

<style>
body{
    font-family: Arial;
    margin:0;
    background: linear-gradient(-45deg,#f4f6f9,#e0f2fe,#fefce8,#e2e8f0);
    background-size:400% 400%;
    animation:bgMove 12s ease infinite;
}

@keyframes bgMove{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
}

/* TOPBAR */
.topbar{
    background: linear-gradient(90deg,#ffe600,#ffd000);
    padding:20px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

/* CONTAINER (CENTERED LIKE YOUR DASHBOARD) */
.container{
    max-width:900px;
    margin:50px auto;
    padding:20px;
}

/* CARD */
.card{
    background:white;
    padding:35px;
    border-radius:14px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* FORM */
label{
    display:block;
    margin-top:15px;
    font-weight:600;
    font-size:14px;
}

input, select{
    width:100%;
    padding:12px;
    margin-top:6px;
    border-radius:10px;
    border:1px solid #e5e7eb;
    outline:none;
}

input:focus, select:focus{
    border-color:#2563eb;
    box-shadow:0 0 0 3px rgba(37,99,235,0.15);
}

/* BUTTONS */
.btn{
    padding:10px 14px;
    border:none;
    border-radius:8px;
    color:white;
    cursor:pointer;
    font-weight:600;
    margin-top:20px;
    width:100%;
}

.btn-save{
    background:#2563eb;
}

.btn-save:hover{
    background:#1d4ed8;
}

.btn-back{
    background:#6b7280;
    margin-top:10px;
}

/* HEADER TITLE */
.title{
    font-size:20px;
    font-weight:700;
    margin-bottom:15px;
}

.sub{
    font-size:13px;
    color:#6b7280;
    margin-bottom:20px;
}
</style>

</head>

<body>

<div class="topbar">
    <h2>Dean Panel</h2>
    <a href="dean_dashboard.php" style="color:#333;text-decoration:none;font-weight:600;">← Back</a>
</div>

<div class="container">

    <div class="card">

        <div class="title">Update User</div>
        <div class="sub">Edit admin or dean account details</div>

        <form method="POST">

            <label>Full Name</label>
            <input type="text" name="fullname" value="<?= $user['fullname'] ?>" required>

            <label>Email</label>
            <input type="email" name="email" value="<?= $user['email'] ?>" required>

            <label>Password (leave blank if no change)</label>
            <input type="password" name="password">

            <label>Role</label>
            <select name="role">
                <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
                <option value="dean" <?= $user['role']=='dean'?'selected':'' ?>>Dean</option>
            </select>

            <button type="submit" name="update" class="btn btn-save">
                Update User
            </button>

            <button type="button" class="btn btn-back"
            onclick="window.location.href='dean_dashboard.php'">
                Cancel
            </button>

        </form>

    </div>

</div>

</body>
</html>