<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "enrollmentsystem"; // FIXED (matches your SQL)

$conn = new mysqli($host, $user, $pass, $db);

/* =========================
   CONNECTION CHECK
========================= */
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

/* =========================
   SAFE SESSION START
========================= */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

?>