<?php

session_start();
include 'connect.php';
require_once 'includes/header.php';

/* =========================
   STUDENT ONLY ACCESS
========================= */
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'student'){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

/* =========================
   GET STUDENT INFO (JOIN FIXED)
========================= */
$studentQuery = $conn->query("
    SELECT 
        users.fullname,
        tblstudent.yearlevel,
        tblstudent.program_id,
        tblprogram.program_name
    FROM users
    INNER JOIN tblstudent
        ON users.id = tblstudent.user_id
    LEFT JOIN tblprogram
        ON tblstudent.program_id = tblprogram.program_id
    WHERE users.id = $user_id
");

$student = $studentQuery->fetch_assoc();

$fullname = $student['fullname'];
$yearlevel = $student['yearlevel'];
$program_id = $student['program_id'];
$program_name = $student['program_name'];

/* =========================
   GET SUBJECTS (SAFE VERSION)
   NOTE: assumes tblsubject uses program_id + yearlevel
========================= */
$subjectQuery = $conn->query("
    SELECT *
    FROM tblsubject
    WHERE program_id = $program_id
    AND yearlevel = $yearlevel
");

?>

<!DOCTYPE html>
<html>
<head>

<title>Student Dashboard</title>

<style>

body{
    font-family: Arial;
    margin: 0;
    background: linear-gradient(-45deg, #f4f6f9, #e0f2fe, #fefce8, #e2e8f0);
    background-size: 400% 400%;
    animation: bgMove 12s ease infinite;
}

@keyframes bgMove{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
}

.topbar{
    background: linear-gradient(90deg, #ffe600, #ffd000);
    padding: 20px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.btn{
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    color: white;
    text-decoration: none;
}

.btn-logout{
    background: #6c757d;
}

.kpi-grid{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    padding: 25px 50px;
}

.kpi-card{
    background: white;
    padding: 20px;
    border-radius: 14px;
}

.container{
    padding: 50px;
}

.card{
    background: white;
    padding: 30px;
    border-radius: 14px;
}

table{
    width: 100%;
    border-collapse: collapse;
}

th{
    background: #007bff;
    color: white;
    padding: 14px;
}

td{
    padding: 14px;
    border-bottom: 1px solid #eee;
}

.subject-tag{
    background: #16a34a;
    color: white;
    padding: 5px 10px;
    border-radius: 6px;
    font-size: 12px;
}

</style>

</head>

<body>

<!-- TOP BAR -->
<div class="topbar">

    <h2>STUDENT DASHBOARD</h2>

    <a href="logout.php" class="btn btn-logout">Logout</a>

</div>

<!-- KPI -->
<div class="kpi-grid">

    <div class="kpi-card">
        <h4>Welcome</h4>
        <h2><?php echo $fullname; ?></h2>
    </div>

    <div class="kpi-card">
        <h4>Program</h4>
        <h2><?php echo $program_name ?? 'Not Assigned'; ?></h2>
    </div>

    <div class="kpi-card">
        <h4>Year Level</h4>
        <h2><?php echo $yearlevel; ?></h2>
    </div>

</div>

<!-- SUBJECTS -->
<div class="container">

    <div class="card">

        <h3>My Subjects</h3>
        <p>Subjects automatically assigned based on your program and year level.</p>

        <table>

            <thead>
                <tr>
                    <th>Subject ID</th>
                    <th>Subject Name</th>
                    <th>Program</th>
                    <th>Year Level</th>
                    <th>Status</th>
                </tr>
            </thead>

            <tbody>

            <?php if($subjectQuery && $subjectQuery->num_rows > 0): ?>

                <?php while($row = $subjectQuery->fetch_assoc()): ?>

                    <tr>
                        <td><?php echo $row['subject_id']; ?></td>
                        <td><?php echo $row['subject_name']; ?></td>
                        <td><?php echo $program_name; ?></td>
                        <td><?php echo $yearlevel; ?></td>
                        <td><span class="subject-tag">Enrolled</span></td>
                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>
                    <td colspan="5">No subjects found for this program/year level</td>
                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>